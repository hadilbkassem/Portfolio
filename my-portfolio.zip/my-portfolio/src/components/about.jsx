import '../styles/sections.css';
import '../styles/about.css';
function About() {
  return (
    <div className='container'>
      <div className="divider">About</div>


     <div className='cards'>
      <div className='par_1'>
        Bachelor's degree in cs | Lebanese University | 2025 <br />

      </div>
      <div className='par_1'>
        Master's degree in  cs | Lebanese University | current <br />
      </div>
      <div className='par_1'>
        Languages : English , French and Arabic <br />
      </div>


      </div>

    </div>
  );
}

export default About;
